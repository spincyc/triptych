#!/usr/bin/env python3
"""Replay mechanical Studiorum Ducem OCR without authored source wording."""
import argparse, hashlib, json, os, subprocess, tempfile, zipfile
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def select(base, recipe):
    parts = []
    for row in recipe['pages']:
        lines = (base / 'raw' / f"page-{row['parent_pdf_page']}.txt").read_text().splitlines(keepends=True)
        parts.append(''.join(lines[row['drop_initial_raw_lines']:]).strip())
    return ('\n\n'.join(parts) + '\n').encode()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--ocr-replay', type=Path)
    parser.add_argument('--model-package', type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    recipe = json.loads((base / 'recipe.json').read_text())
    for name, sha in recipe['input_hashes'].items():
        if digest(base / name) != sha:
            raise SystemExit('input hash mismatch: ' + name)
    if args.ocr_replay:
        if digest(args.ocr_replay) != recipe['parent_pdf_sha256']:
            raise SystemExit('facsimile hash mismatch')
        if not args.model_package or digest(args.model_package) != recipe['model_package_sha256']:
            raise SystemExit('model package hash mismatch')
        for name, sha in recipe['tool_sha256'].items():
            if digest(Path('/usr/bin') / name) != sha:
                raise SystemExit('tool hash mismatch: ' + name)
        env = {**os.environ, 'OMP_THREAD_LIMIT': '1'}
        with tempfile.TemporaryDirectory(dir=args.out.parent) as tmp:
            tmp = Path(tmp)
            with zipfile.ZipFile(args.model_package) as package:
                (tmp / 'eng.traineddata').write_bytes(package.read('eng.traineddata'))
            if digest(tmp / 'eng.traineddata') != recipe['model_sha256']:
                raise SystemExit('model hash mismatch')
            for row in recipe['pages']:
                n = row['parent_pdf_page']
                prefix = tmp / f'page-{n}'
                full = tmp / f'full-{n}.png'
                subprocess.run(['/usr/bin/pdftoppm', '-f', str(n), '-l', str(n), '-r', '300', '-png', '-singlefile', str(args.ocr_replay), str(full.with_suffix(''))], check=True, capture_output=True, env=env)
                if digest(full) != row['full_image_sha256']:
                    raise SystemExit('full image mismatch: ' + str(n))
                x, y, w, h = row['crop']
                subprocess.run(['/usr/bin/magick', str(full), '-crop', f'{w}x{h}+{x}+{y}', '+repage', '-strip', str(prefix.with_suffix('.png'))], check=True, capture_output=True, env=env)
                if digest(prefix.with_suffix('.png')) != row['crop_sha256']:
                    raise SystemExit('crop mismatch: ' + str(n))
                subprocess.run(['/usr/bin/tesseract', str(prefix.with_suffix('.png')), str(prefix), '--tessdata-dir', str(tmp), '-l', 'eng', '--psm', '3', '-c', 'tessedit_create_txt=1', '-c', 'tessedit_create_tsv=1'], check=True, capture_output=True, env=env)
                for suffix, key in [('.txt', 'raw_text_sha256'), ('.tsv', 'tsv_sha256')]:
                    if digest(prefix.with_suffix(suffix)) != row[key]:
                        raise SystemExit('OCR mismatch: ' + str(n) + suffix)
                print('OCR replay pass:', n, flush=True)
    result = select(base, recipe)
    if hashlib.sha256(result).hexdigest() != recipe['reading_sha256']:
        raise SystemExit('reading hash mismatch')
    args.out.write_bytes(result)
    print('Reading replay pass:', recipe['reading_sha256'])

if __name__ == '__main__':
    main()
