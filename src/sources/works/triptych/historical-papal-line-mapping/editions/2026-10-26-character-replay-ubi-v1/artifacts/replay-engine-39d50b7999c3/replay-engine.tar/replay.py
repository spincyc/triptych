from pathlib import Path
import argparse
import _bullarium_character_geometry as engine
p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--recipe',type=Path,required=True)
p.add_argument('--input-map',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--check',action='store_true')
a=p.parse_args()
fn=engine.check if a.check else engine.build
fn(a.root,a.recipe,a.out,input_map=a.input_map)
