#!/usr/bin/python3
"""Rebuild a pixel-preserving EAP JPEG-tile facsimile, without a network.

Project-created code: MIT. Source images retain CC BY-NC 4.0, as explained in
ATTRIBUTION.txt. Run from an extracted package, choosing an output directory:
python3 REBUILD.py --out /path/to/scratch/output [--native-png]
Native PNG reconstruction additionally requires ImageMagick 7 (magick).
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent


def checked(row):
    raw = (ROOT / row["path"]).read_bytes()
    assert len(raw) == row["byte_size"]
    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
    return raw


def pdf_bytes(receipt, attribution):
    objects = []

    def add(raw):
        objects.append(raw)
        return len(objects)

    add(b"<< /Type /Catalog /Pages 2 0 R >>")
    add(b"")
    pages = []
    for frame in receipt["frames"]:
        width, height = frame["width"], frame["height"]
        commands, resources = [], []
        for n, tile in enumerate(frame["tiles"]):
            raw = checked(tile)
            image_id = add(("<< /Type /XObject /Subtype /Image /Width %d /Height %d "
                            "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode "
                            "/Interpolate false /Length %d >>\nstream\n" %
                            (tile["width"], tile["height"], len(raw))).encode() + raw + b"\nendstream")
            resources.append(f"/Im{n} {image_id} 0 R")
            commands.append("q %d 0 0 %d %d %d cm /Im%d Do Q\n" %
                            (tile["width"], tile["height"], tile["x"],
                             height-tile["y"]-tile["height"], n))
        content = "".join(commands).encode()
        content_id = add((f"<< /Length {len(content)} >>\nstream\n").encode()+content+b"endstream")
        pages.append(add((f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {width} {height}] "
                          f"/Resources << /XObject << {' '.join(resources)} >> >> "
                          f"/Contents {content_id} 0 R >>").encode()))
    font = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    lines = attribution.splitlines()
    text = ["BT /F1 10 Tf 45 795 Td 13 TL\n"]
    for n, line in enumerate(lines):
        escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        if n:
            text.append("T*\n")
        text.append(f"({escaped}) Tj\n")
    text.append("ET\n")
    content = "".join(text).encode("ascii")
    assert len(lines) <= 55
    content_id = add((f"<< /Length {len(content)} >>\nstream\n").encode()+content+b"endstream")
    pages.append(add((f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
                      f"/Resources << /Font << /F1 {font} 0 R >> >> /Contents {content_id} 0 R >>").encode()))
    objects[1] = (f"<< /Type /Pages /Count {len(pages)} /Kids [" +
                  " ".join(f"{p} 0 R" for p in pages)+"] >>").encode()
    info = add(b"<< /Title (Lyturgia Armena, Rome 1677, EAP180/1/1/12) "
               b"/Subject (18 source frames plus a project attribution page; CC BY-NC 4.0) "
               b"/Creator (Triptych mechanical facsimile packaging) >>")
    pdf = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for number, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf.extend(f"{number} 0 obj\n".encode()+obj+b"\nendobj\n")
    start = len(pdf)
    pdf.extend(f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode())
    pdf.extend((f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R /Info {info} 0 R >>\n"
                f"startxref\n{start}\n%%EOF\n").encode())
    return bytes(pdf)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--native-png", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    receipt = json.loads((ROOT / "acquisition-receipt.json").read_text())
    assert len(receipt["frames"]) == 18
    assert sum(len(f["tiles"]) for f in receipt["frames"]) == 159
    for frame in receipt["frames"]:
        checked(frame["metadata"])
    attribution = (ROOT / "ATTRIBUTION.txt").read_text(encoding="ascii")
    path = args.out / "eap180-1-1-12-native-facsimile.pdf"
    path.write_bytes(pdf_bytes(receipt, attribution))
    if args.native_png:
        for frame in receipt["frames"]:
            path = args.out / f"frame-{frame['frame']:02d}.png"
            command = ["magick", "-size", f"{frame['width']}x{frame['height']}", "xc:black"]
            for tile in frame["tiles"]:
                checked(tile)
                command += [str(ROOT / tile["path"]), "-geometry",
                            f"+{tile['x']}+{tile['y']}", "-composite"]
            command += ["-depth", "8", "-strip", "-define", "png:exclude-chunk=date,time",
                        f"PNG24:{path}"]
            subprocess.run(command, check=True)
    print("Built 19-page PDF: 18 unaltered source-frame canvases plus attribution.")


if __name__ == "__main__":
    main()
