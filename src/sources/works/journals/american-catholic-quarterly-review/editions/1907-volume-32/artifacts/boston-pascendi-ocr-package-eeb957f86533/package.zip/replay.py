#!/usr/bin/env python3
"""Replay bounded OCR source selection; source letters come only from OCR bytes."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,os,tempfile

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s): return re.sub(r'\s+',' ',s).strip()
def blocks(s): return '\n\n'.join(norm(b) for b in re.split(r'\n\s*\n',s.strip()) if b.strip())
def select(base):
 parts=[]
 for page in range(705,731):
  lines=(base/'raw'/f'page-{page}.txt').read_text().splitlines()
  if page==705:
   title=(base/'raw/title.txt').read_text().strip()
   letter=(base/'raw/dropcap-letter.txt').read_text().strip()
   first=(base/'raw/first-lines.txt').read_text().strip()
   # All coordinates and LF selectors are explicit in recipe.json.
   opening=letter+norm(first)+' '+norm('\n'.join(lines[16:28]))
   value=title+'\n\n'+opening+'\n\n'+'\n'.join(lines[31:])
  elif page==729:
   a=(base/'raw/p729-line.txt').read_text().strip()
   b=(base/'raw/p729-lastword.txt').read_text().strip()
   value='\n'.join(lines[:70])+'\n'+a+'\n'+b+'\n\n'+'\n'.join(lines[74:])
  else:value='\n'.join(lines)
  parts.append(blocks(value))
 return ('\n\n'.join(parts)+'\n').encode()

def main():
 a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);a.add_argument('--ocr-replay',type=Path);ns=a.parse_args()
 base=Path(__file__).resolve().parent; recipe=json.loads((base/'recipe.json').read_text())
 for name,sha in recipe['input_hashes'].items():
  if digest(base/name)!=sha:raise SystemExit('input hash mismatch: '+name)
 if ns.ocr_replay:
  pdf=ns.ocr_replay
  if digest(pdf)!=recipe['bounded_pdf_sha256']:raise SystemExit('bounded PDF hash mismatch')
  for tool,sha in recipe['tool_sha256'].items():
   if digest(Path('/usr/bin')/tool)!=sha:raise SystemExit('tool hash mismatch: '+tool)
  def run(args):return subprocess.run(args,check=True,capture_output=True,env={**os.environ,'OMP_THREAD_LIMIT':'1'})
  with tempfile.TemporaryDirectory(dir=ns.out.parent) as td:
   td=Path(td)
   for row in recipe['pages']:
    n=row['printed_page'];full=td/f'{n}-full.png';crop=td/f'{n}.png';ocr=td/f'{n}'
    run(['pdftoppm','-f',str(n-704),'-l',str(n-704),'-r','300','-gray','-png','-singlefile',str(pdf),str(full.with_suffix(''))])
    if digest(full)!=row['full_image_sha256']:raise SystemExit('full image mismatch '+str(n))
    x,y,w,h=row['crop'];run(['magick',str(full),'-crop',f'{w}x{h}+{x}+{y}','+repage','-strip','-strip',str(crop)])
    if digest(crop)!=row['crop_sha256']:raise SystemExit('crop mismatch '+str(n))
    run(['tesseract',str(crop),str(ocr),'--tessdata-dir',str(base),'-l','eng','--psm','3','-c','tessedit_create_txt=1','-c','tessedit_create_tsv=1'])
    if digest(ocr.with_suffix('.txt'))!=row['raw_text_sha256'] or digest(ocr.with_suffix('.tsv'))!=row['tsv_sha256']:raise SystemExit('OCR mismatch '+str(n))
   for row in recipe['special_crops']:
    n=row['page'];full=td/f'{n}-full.png';im=td/(row['name']+'.png');ocr=td/row['name'];x,y,w,h=row['crop']
    args=['magick',str(full),'-crop',f'{w}x{h}+{x}+{y}','+repage','-strip']
    if row.get('threshold'):args+=['-threshold','50%','-bordercolor','white','-border','20']
    run(args+[str(im)])
    if digest(im)!=row['image_sha256']:raise SystemExit('special crop mismatch '+row['name'])
    args=['tesseract',str(im),str(ocr),'--tessdata-dir',str(base),'-l','eng','--psm',str(row['psm'])]
    if row.get('threshold'):args+=['-c','tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ']
    run(args+['-c','tessedit_create_txt=1','-c','tessedit_create_tsv=1'])
    if digest(ocr.with_suffix('.txt'))!=row['text_sha256'] or digest(ocr.with_suffix('.tsv'))!=row['tsv_sha256']:raise SystemExit('special OCR mismatch '+row['name'])
 out=select(base)
 if hashlib.sha256(out).hexdigest()!=recipe['output_sha256']:raise SystemExit('selection output mismatch')
 ns.out.write_bytes(out);print(json.dumps({'output_sha256':hashlib.sha256(out).hexdigest(),'byte_size':len(out),'ocr_replayed':bool(ns.ocr_replay)}))
if __name__=='__main__':main()
